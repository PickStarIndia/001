------------------
$Typo_Today
A CSS+(X)HTML-based template.
Designed by $Edwin_Lunandy ($http://population-2.com/)
$A theme for blog or portfolio
------------------

You can download the fonts here:
1. Bambi http://www.dafont.com/search.php?psize=m&q=bambi copyright of Gerard E. Bernor
2. Gentium Basic http://www.fontsquirrel.com/fonts/Gentium-Basic copyright of SIL International

Cufon http://cufon.shoqolate.com/generate/


Dear friends,

thank you for downloading this file.

You can freely use this template for both your private and commercial projects, including software, online services, templates and themes.
